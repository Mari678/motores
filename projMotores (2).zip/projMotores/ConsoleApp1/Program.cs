﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static double[] valor;

        static void inverteTela()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
        }
        static void lancar()
        {
            int motor;
            do
            {
                Console.Write("Qual o motor ?");
                motor = int.Parse(Console.ReadLine());
            }
            while (motor < 1 || motor > 15);

            Console.Write("Qual o valor ?");
            valor[motor - 1] += double.Parse(Console.ReadLine());

            Console.WriteLine("Valor registrado!");

        }
        static void mostrar()
        {
            int motor;
            double total;

            total = 0;
            for (motor = 0; motor < 15; motor++)
            {
                Console.WriteLine("Motor {0}: R$ {1}",
                    motor + 1, valor[motor]);
                total += valor[motor];
            }
            Console.WriteLine("-------");
            Console.WriteLine("Total: R$ {0}", total);

        }
        static void maiorv()
        {
            int x;
            double maior = 0;
            double posmaior = 0;

           if (valor.Sum() == 0)
            {
                Console.WriteLine("Até o momento, não houve gasto em nenhum motor.");
            }
           else
            {
                for (x = 0; x < 15; x ++)
                {
                    if (valor [x] > maior)
                    {
                        maior = valor [x];
                        posmaior = x;
                    }
                }
                Console.WriteLine("O motor com maior gasto foi o motor {0}", posmaior + 1);
                Console.WriteLine("O valor gasto foi R$ {0}", maior);
            }
        }
        static void menorv()
        {
            int i = 0;
            double menor = 0;
            double imenor = 0;

            while (i < 15 && valor[i] == 0)
            {
                ++i;
            }

            if (i == 15)
            {
                Console.WriteLine("Até o momento, não houve gasto em nenhum motor.");
            }
            else
            {
                menor = valor[i];
                imenor = i;
                for (int j = i +1; j < 15; ++j)
                {
                    if (valor[i] < menor)
                    {
                        menor = valor[i];
                        imenor = i;
                    }
                }
                Console.WriteLine("O motor com menor gasto foi o motor {0}", imenor + 1);
                Console.WriteLine("O valor gasto foi R$ {0}", menor);
            }
        }
        static void Main(string[] args)
        {
            
            valor = new double[15];
            int op;
            
            inverteTela();

            do
            {
                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Lançar valor");
                Console.WriteLine("2. Mostrar valores");
                Console.WriteLine("3. Qual motor teve o maior gasto?");
                Console.WriteLine("4. Qual motor teve o menor gasto?");
                Console.Write("Sua opção: ");
                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        {
                            lancar();
                            break;
                        }
                    case 2:
                        {
                            mostrar();
                            break;
                        }
                    case 3:
                        {
                            maiorv();
                            break;
                        }
                    case 4:
                        {
                            menorv();
                            break;
                        }
                }
            }
            while (op != 0);
        }
    }
}
